-- IMA Lda v4 — Corre no Supabase → SQL Editor → New Query

-- Remover triggers antigos
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP TRIGGER IF EXISTS tickets_updated_at ON public.tickets;
DROP FUNCTION IF EXISTS handle_new_user() CASCADE;
DROP FUNCTION IF EXISTS update_updated_at() CASCADE;

-- Departamentos
CREATE TABLE IF NOT EXISTS public.departamentos (
  id bigserial primary key,
  nome text not null,
  descricao text,
  created_at timestamptz default now()
);

-- Profiles (adicionar colunas novas)
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS departamento_id bigint references public.departamentos(id);
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS email_notif text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS ativo boolean default true;

-- Tickets (adicionar coluna departamento)
ALTER TABLE public.tickets ADD COLUMN IF NOT EXISTS departamento_id bigint references public.departamentos(id);

-- Avisos
CREATE TABLE IF NOT EXISTS public.avisos (
  id bigserial primary key,
  titulo text not null,
  texto text not null,
  autor_id uuid references public.profiles(id),
  created_at timestamptz default now()
);

-- RLS departamentos
ALTER TABLE public.departamentos ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "auth_read_dep" ON public.departamentos;
DROP POLICY IF EXISTS "auth_ins_dep" ON public.departamentos;
DROP POLICY IF EXISTS "auth_upd_dep" ON public.departamentos;
DROP POLICY IF EXISTS "auth_del_dep" ON public.departamentos;
CREATE POLICY "auth_read_dep" ON public.departamentos FOR SELECT USING (auth.role()='authenticated');
CREATE POLICY "auth_ins_dep" ON public.departamentos FOR INSERT WITH CHECK (auth.role()='authenticated');
CREATE POLICY "auth_upd_dep" ON public.departamentos FOR UPDATE USING (auth.role()='authenticated');
CREATE POLICY "auth_del_dep" ON public.departamentos FOR DELETE USING (auth.role()='authenticated');

-- RLS avisos
ALTER TABLE public.avisos ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "auth_read_av" ON public.avisos;
DROP POLICY IF EXISTS "auth_ins_av" ON public.avisos;
CREATE POLICY "auth_read_av" ON public.avisos FOR SELECT USING (auth.role()='authenticated');
CREATE POLICY "auth_ins_av" ON public.avisos FOR INSERT WITH CHECK (auth.role()='authenticated');

-- Trigger updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at=now(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER tickets_updated_at BEFORE UPDATE ON public.tickets
FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Trigger criar perfil
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles(id,nome,cargo,role)
  VALUES(NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'nome', split_part(NEW.email,'@',1)),
    NEW.raw_user_meta_data->>'cargo',
    COALESCE(NEW.raw_user_meta_data->>'role','colaborador'))
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Departamentos iniciais
INSERT INTO public.departamentos(nome,descricao) VALUES
('Manutenção','Equipamentos e infraestrutura'),
('Comercial','Vendas e clientes'),
('Administrativo','Administração e finanças'),
('Logística','Entregas e stock')
ON CONFLICT DO NOTHING;

-- Atualizar perfis da equipa
UPDATE public.profiles SET role='gestor', cargo='Diretor Geral', email_notif='marcio@ima.co.ao', nome='Marcio'
  WHERE id=(SELECT id FROM auth.users WHERE email='marcio@ima.co.ao');

UPDATE public.profiles SET role='colaborador', cargo='Financeiro', email_notif='filipe@ima.co.ao', nome='Filipe'
  WHERE id=(SELECT id FROM auth.users WHERE email='filipe@ima.co.ao');

UPDATE public.profiles SET role='colaborador', cargo='Aux. Adm. Grill & Gelo', email_notif='emanuel@ima.co.ao', nome='Emanuel'
  WHERE id=(SELECT id FROM auth.users WHERE email='emanuel@ima.co.ao');

UPDATE public.profiles SET role='colaborador', cargo='Aux. Gelo & Manutenção', email_notif='ricardo@ima.co.ao', nome='Ricardo'
  WHERE id=(SELECT id FROM auth.users WHERE email='ricardo@ima.co.ao');
